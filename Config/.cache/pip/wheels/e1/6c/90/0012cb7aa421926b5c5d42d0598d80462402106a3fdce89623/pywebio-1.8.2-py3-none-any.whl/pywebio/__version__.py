__package__ = 'pywebio'
__description__ = 'Write interactive web app in script way.'
__url__ = 'https://pywebio.readthedocs.io'
__version__ = "1.8.2"
__version_info__ = (1, 8, 2, 0)
__author__ = 'WangWeimin'
__author_email__ = 'wang0.618@qq.com'
__license__ = 'MIT'
